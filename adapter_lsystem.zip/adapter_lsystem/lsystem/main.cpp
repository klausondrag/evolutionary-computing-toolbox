/*
 * Genome indirect enconding: L-System
 * Author: Karine Miras
 * Created: 02/03/17
 */

#include<iostream>
#include <random>
#include "EvolutionIndirect.h"

using namespace std;


int main(int argc, char* argv[])
{

     /* THIS IS AN ADAPTER FROM DIRECT TO INDIRECT ENCODING, RAGARDING ONLY THE BODY,
     * WHICH LOADS A SET OF ROBOTS IN ROBOGEN FORMAT, TRANSFORMS THEM INTO THE INTERMEDIATE PHENOTYPE,
     * DEVELOPS, DRAWS AND MEASURES THEM.
     * NOTE: this works only for the body descriptors, so just ignore the brain descriptors.
     *
     * STEPS:
     * 1 - check the example folder experiments/direct-1
     * 2 - set exp_name to your experiment name
     * 3 - create a new folder with the name exp_name, containing a subfolder called offspringpop
     * 4 - set the parameter pop_size in configurarion.txt with the number of robots you have
     * 5 - convert your robots from yaml to robogen files
     * 6 - rename your robogen files as genome0.txt...genome{pop_size-1}.txt
     * 7 - copy the robogen files to the folder named as exp_name/offspringpop
     * 8 - compile and run this code
     * 9 - check the outputs. hint: new yaml files will also be exported, so you can use then to validate if your yaml/robogen conversion was correct.
     * */

    std::string exp_name = "direct-1";

    EvolutionIndirect evolve_generation = EvolutionIndirect(exp_name,"../../");

    evolve_generation.loadDirectRobots();


    return 0;
}


